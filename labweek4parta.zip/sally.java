 
public class sally
{
    
    String person = "Sally";
    String person2 = "Mike";
    String person3 = "Mike";
    String person4 = "Rob";
    String lyrics = "And so Sally can wait, she knows it's too late as we're walking on by";
    int age = 18;
    int leave_school = 16;
    int army = 17;
    int vote = 18;
    int claim = 22;
    int insurance = 26;
    
   
    public sally()
    {
     System.out.print("\u000c");
     
        {
         if (age > leave_school)
         {   
             System.out.println("\n\nName ="+person+" age="+age);
            }
        else if (age > army)
            { 
            System.out.println("\n\nName ="+person2+" age="+age);   
        }
            else if (true) 
                System.out.print( "be conscipted");
          {
              if (age > vote)
              {
                  System.out.println("\n\nName ="+person4+" age="+age);
            }
                else if (true)
                System.out.print("test dont be conscripted ");
            {
              //if (age )   
          
        }
     }
    }
}
}
