import java.util.*;

/**
 * This is the index/menu
 *
 * Annabelle Chen u31605
 * version 1
 *       LIST:
      1) need to enter user + password + only work if correct
        --> has to be sensitive to uppercase and lowercase
      2) need to enter student ID + unit (should compare.to or switch statement)
      3) print out the final grade using if statement   
 */
public class InputMarks
{
     String Account;
     String Password;
     String ID;
     double Math;
     double Biology;
     double IT;
     double Painting;
     double History;
     
     String Scanner;
    public InputMarks()
    {
      System.out.print("\u000c");
      
      Scanner in = new Scanner(System.in);
      System.out.println("Please enter your Account: ");
      String Account = in.nextLine();
      
          if (Account.compareTo("s43123") ==0)
       {
          System.out.println("Please enter your Password: ");
          String Password = in.nextLine();
          if (Password.compareTo("-North2020/") ==0)
          {
            System.out.println("Please input the student ID");  
            String ID = in.nextLine();
            
            System.out.println("Please enter Math marks");  
            double Math = in.nextInt();
            System.out.println("Please enter IT marks"); 
            double IT = in.nextInt();
            System.out.println("Please enter Biology marks");  
            double Biology = in.nextInt();
            System.out.println("Please enter Painting marks"); 
            double Painting = in.nextInt();
            System.out.println("Please enter History marks");  
            double History = in.nextInt();
            }
          
        } else System.out.println("Incorrect account, please try again"); 
        
        double finalmarks = getMarks(Math);
        System.out.println("========================");
        System.out.println("The marks for student"+ID +"is: ");
        System.out.println("Final marks: "+finalmarks);
        System.out.println();
        System.out.println();
    }
    
    public double getMarks(double Mathmarks)
    {
      //weight calculations for maths
      double retv=0;
      Mathmarks = Math*0.3;
      retv = Mathmarks;
      return retv;
    }
}
