
/**
 * This is where all of the results are printed/displayed
 * this calls the InputMarks class
 * @author (your name)
 * @version (a version number or a date)
 */
public class Display
{
    public Display()
    {
            System.out.print("\u000c");
            loopingandclasslinks_OfInputMarks loop = new loopingandclasslinks_OfInputMarks();
    }
}
