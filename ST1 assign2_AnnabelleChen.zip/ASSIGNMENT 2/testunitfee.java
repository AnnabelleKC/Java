import java.util.*;
import java.io.*;
/**
 * This is the final input class for data + results
 *
 * @author Annabelle Chen
 * @version 3
 */
public class testunitfee //extends inputclass
{
      public String Account;
     public String Password;
     public String ID;
     public String retry;
     public int Math;
     public int Biology;
     public int IT;
     public int Painting;
     public int History;
     public int ecology;
     public int accounting;
     public int chief;
     public int spanish;
     public int FinalMarks;
     public String Unitcode;
     
     String Scanner;
      public testunitfee()
    {
      System.out.print("\u000c");
      getMarks();
    }
    
      public void getMarks()
    {
           Scanner in = new Scanner(System.in);
            boolean loopAgain=true;
            System.out.println("             =========================\n");
            System.out.println("   ! Welcome to The Garden School Grade System  !\n");
            System.out.println("             =========================\n");
            System.out.println();
          do {
         
              try{
                System.out.println("Please enter your Account: ");
                String Account = in.nextLine().trim();
                if (Account.compareTo("u123") ==0)
                {
                   studentlogin();
                 } else
                  if (Account.compareTo("s43123") ==0)  
               {
                  System.out.println("Please enter your Password: ");
                  String Password = in.nextLine().trim();
                    if (Password.compareTo("-North2020/") ==0)   
                  {
                    System.out.println("Login successful!");
                    System.out.println("Please input the student's ID");  
                    String ID = in.nextLine().trim();
                    
                    System.out.println("Please enter Math marks");  
                    double Math = in.nextDouble();
                    System.out.println("Please enter IT marks"); 
                    double IT = in.nextDouble();
                    System.out.println("Please enter Biology marks");  
                    double Biology = in.nextDouble();
                    System.out.println("Please enter Painting marks"); 
                    double Painting = in.nextDouble();
                    System.out.println("Please enter History marks");  
                    double History = in.nextDouble();
                    
                    System.out.println();
                    System.out.println("             ==========================\n");
                    double FinalMarks = Math*0.3+Biology*0.2+IT*0.2+Painting*0.1+History*0.2;
                    System.out.println("              Student  "+ID +" Results: \n");
                    System.out.printf("|| Final marks are: %.0f\n",FinalMarks);
                    
                    if (FinalMarks >= 85)
                    {
                        System.out.println("\n || Final Grade is an HD");
                       }
                        else if (FinalMarks >= 75) System.out.println("|| Final Grade is a D");
                            else if (FinalMarks >= 65) System.out.println("|| Final Grade is a C");
                                else if (FinalMarks >= 50) System.out.println("|| Final Grade is a P");
                                    else if (FinalMarks < 50) System.out.println("|| Final Grade is an F\n Student needs to enrol next semester");
                                        else if (FinalMarks == 0) System.out.println("|| Did not attend\n Student need to explain their absence and enrol next semester");
                     if (Math == 90) { System.out.println("-- Student can attend a maths contest");} 
                     if (Biology >= 75) {System.out.println("-- Student can apply for the Ecology unit");}
                     if (IT >= 85) {System.out.println("-- Student can get a Microsoft certificate");}
                     if (Painting >= 85) {System.out.println("-- Student's production can be displayed on the school website");}
                     if (FinalMarks >= 85) {System.out.println("-- Student can apply for a scholarship\n");}
                     System.out.println("             ==========================\n");
                   } else System.out.println("\nIncorrect Password, please try again");
                  
                } else System.out.println("\nIncorrect Account, please try again"); 
 
              } catch (InputMismatchException e) {System.out.println("incorrect details! try again");}
        } while (loopAgain=true);
        getMarks();
        
    }
      public void studentlogin()
    {
        Scanner in = new Scanner(System.in);
        boolean loopAgain=true;
        System.out.println("Please enter your Password: ");
        String Password = in.nextLine().toLowerCase().trim();
        do
        {
            try
            {
                if (Password.compareTo("u123") ==0)
                   {
                     int mmath = 48;
                     int bbiology = 52;
                     int iit = 53;
                     int ppainting = 45;
                     int hhistory = 38; 
                     System.out.println("--------------------");
                     System.out.println("\n || Login successful! ||");
                     System.out.println("Name:         Tom");
                     System.out.println("ID:           u123");
                     System.out.println("Password:     u123");
                     System.out.println("Grades:       Math:  48  |  Biology:  52   |  IT: 53   |  Painting: 45  |  History: 38");
                     System.out.println("Final Grade:  F");
                     System.out.println("Tom needs to enrol into Math, Painting, and History next semester.\n");
        
                     System.out.println("Please input the unit code to enrol\n               OR  \ninput   0   to see final enrolment fees: ");  
                     String Unitcode = in.nextLine().trim();
                     if(Unitcode.compareTo("4483")==0)
                     {
                        if (mmath >=50) 
                        {
                            System.out.println("this is a test for passing");   
                        } else System.out.println("Enrolled for next semester in Math (Plan B) $1200"); 
                    } else System.out.println("Thats not a valid unit, please try again.");
                    if(Unitcode.compareTo("4485")==0)
                        {
                           if (bbiology >=50)
                             {
                                System.out.println("You have already enrolled into Biology"); 
                            } else System.out.println("Enrolled for next semester in Biology (Plan B) $1780");
                        }
                    if(Unitcode.compareTo("4486")==0)
                     {
                        if (iit >=50) 
                        {
                            System.out.println("You have already enrolled into IT"); 
                        } else System.out.println("Enrolled for next semester in IT (Plan B) $1780"); 
                    }    
                    if(Unitcode.compareTo("4487")==0)
                        { 
                           if (ppainting >=50)
                             {
                                System.out.println("You have already enrolled into Painting"); 
                            } else System.out.println("Enrolled for next semester in Painting (Plan B) $1780");
                        }
                    if(Unitcode.compareTo("4488")==0)
                        {
                           if (hhistory >=50)
                             {
                                System.out.println("You have already enrolled into History"); 
                            } else System.out.println("Enrolled for next semester in History (Plan B) $1200");  
                        }
                    if(Unitcode.compareTo("4489")==0)
                        {
                            System.out.println("Enrolled for Ecology (Plan A) $1000"); 
                        }
                    if(Unitcode.compareTo("8873")==0)
                        {
                            System.out.println("Enrolled for Accounting (Plan A) $1000"); 
                        } 
                    if(Unitcode.compareTo("8872")==0)
                        {
                           System.out.println("Enrolled for Chief (Plan A) $1580");
                        }
                    if(Unitcode.compareTo("8871")==0)
                        {
                           System.out.println("Enrolled for Spanish (Plan A) $1200"); 
                        }
                    if(Unitcode.compareTo("0")==0)
                    {
                        System.out.print("Your final Fee for enrolment is:  $"+(1200+1780+1200));
                    }
                   }  else System.out.println("Incorrect Password, Please Try Again."); studentlogin();
            } catch (InputMismatchException e) {System.out.println("incorrect details! try again");}
        } while (loopAgain==true);
         getMarks();   
    }
    
}