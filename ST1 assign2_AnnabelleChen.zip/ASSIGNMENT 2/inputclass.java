import java.util.*;

/**
 * This is the index/menu
 *
 * Annabelle Chen u31605
 * version 4
 */
public class inputclass
{
     public String Account;
     public String Password;
     public String ID;
     public String retry;
     public double Math;
     public double Biology;
     public double IT;
     public double Painting;
     public double History;
     public double FinalMarks;
     public String Unitcode;
     
     String Scanner;
    public inputclass()
    {
      System.out.print("\u000c");
      getMarks();

    }
    
    public void getMarks()
    {
           Scanner in = new Scanner(System.in);
            boolean loopAgain=true;
            System.out.println("             =========================\n");
            System.out.println("   ! Welcome to The Garden School Grade System  !\n");
            System.out.println("             =========================\n");
            System.out.println();
          do {
         
              try{
                System.out.println("Please enter your Account: ");
                String Account = in.nextLine().trim();
                if (Account.compareTo("u123") ==0)
                {
                   studentlogin();
                 } else
                  if (Account.compareTo("s43123") ==0)
               {
                  System.out.println("Please enter your Password: ");
                  String Password = in.nextLine().trim();
                    if (Password.compareTo("-North2020/") ==0)
                  {
                    System.out.println("Login successful!");
                    System.out.println("Please input the student's ID");  
                    String ID = in.nextLine().trim();
                    
                    System.out.println("Please enter Math marks");  
                    double Math = in.nextDouble();
                    System.out.println("Please enter IT marks"); 
                    double IT = in.nextDouble();
                    System.out.println("Please enter Biology marks");  
                    double Biology = in.nextDouble();
                    System.out.println("Please enter Painting marks"); 
                    double Painting = in.nextDouble();
                    System.out.println("Please enter History marks");  
                    double History = in.nextDouble();
                    
                    System.out.println();
                    System.out.println("========================\n");
                    double FinalMarks = Math*0.3+Biology*0.2+IT*0.2+Painting*0.1+History*0.2;
                    System.out.println("Student  "+ID +" Results: \n");
                    System.out.printf("|| Final marks are: %.1f\n",FinalMarks);
                    
                    if (FinalMarks >= 85)
                    {
                        System.out.println("\n || Final Grade is an HD");
                       }
                        else if (FinalMarks >= 75) System.out.println("|| Final Grade is a D");
                            else if (FinalMarks >= 65) System.out.println("|| Final Grade is a C");
                                else if (FinalMarks >= 50) System.out.println("|| Final Grade is a P");
                                    else if (FinalMarks < 50) System.out.println("|| Final Grade is an F\n Student needs to enrol next semester");
                                        else if (FinalMarks == 0) System.out.println("|| Did not attend\n Student need to explain their absence and enrol next semester");
                     if (Math == 90) { System.out.println("-- Student can attend a maths contest");} 
                     if (Biology >= 75) {System.out.println("-- Student can apply for the Ecology unit");}
                     if (IT >= 85) {System.out.println("-- Student can get a Microsoft certificate");}
                     if (Painting >= 85) {System.out.println("-- Student's production can be displayed on the school website");}
                     if (FinalMarks >= 85) {System.out.println("-- Student can apply for a scholarship\n");}
        
                   } else System.out.println("\nIncorrect Password, please try again");
                  
                } else System.out.println("\nIncorrect Account, please try again"); 
 
              } catch (InputMismatchException e) {System.out.println("incorrect details! try again");}
        } while (loopAgain=true);
        getMarks();
        
    }
    public void studentlogin()
    {
        Scanner in = new Scanner(System.in);
        System.out.println("Please enter your Password: ");
        String Password = in.nextLine().trim();
        if (Password.compareTo("u123") ==0)
           {
             System.out.println("--------------------");
             System.out.println("\n || Login successful! ||");
             System.out.println("Name: Tom");
             System.out.println("ID: u123");
             System.out.println("Password: u123");
             System.out.println("Math:  48  |  Biology:  52   |  IT: 53   |  Painting: 45  |  History: 38");
             System.out.println("\nFinal Grade: F");
             System.out.println("\nTom needs to enrol into Math, Painting, and History next semester.\n");

             System.out.println("Please input the unit code to enrol: ");  
             String Unitcode = in.nextLine().trim();
             if(Unitcode=="4483")
               {
                  System.out.print("");  
                }
            }
         getMarks();   
    }
    
}
