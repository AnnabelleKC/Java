public class main1
{
    
    public main1()
    {
        System.out.print('\u000C');
        System.out.println("Hello World!");
        System.out.println("Hello World again");
        System.out.println("Hellow World 22222222 oh 3");
    }

    
}
