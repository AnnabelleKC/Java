
/**
 * examples without lab.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class handrun2
{
    double helyes = 22.2;
    double helno = 1;
    double ans;
  
   
    public handrun2()
    {
        
          helno = helno +1;
          ans = helyes/helno;
        System.out.print("\u000c");
        System.out.println(ans);
    }
     public static void main(String[] args) // program starts here    
    {        
        new handrun2();    
    }
    }

