
/**
 * only printing out main method
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class maincls
{

    public  maincls()
    {
     System.out.print("\u000c");
     System.out.println("helloow World");
    }

    public static void main(String[] args) // program starts here   
    {        new maincls();    }
    }

