
/**
 * handrun 3 example with two answers - numerals and letters.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class handrun3
{
    double helyes = 22.2;
    double helno = 1;
    double ans;
    public handrun3()
    {
      helno=helno+1;
      ans = helyes/helno; 
      System.out.print("\u000c");
      System.out.println("Its a trap ");
      System.out.println(helyes);
    }
    public static void main(String[] args) // program starts here    
    {        
        new handrun3();    
    }

    }
