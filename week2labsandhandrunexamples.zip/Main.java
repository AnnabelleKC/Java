
/**
 * writing main method and using numbers.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Main
{
    int ned = 5;
    int stark = 7;
    public Main()  // constructor for class Main
    {
     System.out.print("\u000c");
     System.out.print("ned plus stark is ");
     System.out.println(ned+stark);
    }
     public static void main(String[] args) // program starts here    
    {        
        new Main();    
    }
     
    }
 
