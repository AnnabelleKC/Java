
/**
 * HandRunExamples (not lab tasks).
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class handrun
{
    int a = 3;
    int bb = 7;
    int dixit = a+bb-1;
    public handrun()   // constructor for class handrun
    {
     System.out.print("\u000c");
     System.out.print("The value of dixit is: ");
     System.out.println(dixit);
    }
    public static void main(String[] args) // program starts here    
    {        
        new handrun();    
    }
    }

